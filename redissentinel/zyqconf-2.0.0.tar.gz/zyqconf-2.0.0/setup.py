#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
setup
~~~~~~~~~~~~

setup for install

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-09-19

"""

import sys
import os
import re
from distutils.core import setup
from distutils.command.install_data import install_data
from distutils.command.install import INSTALL_SCHEMES

cmdclasses = {'install_data': install_data}

for scheme in INSTALL_SCHEMES.values():
    scheme['data'] = scheme['purelib']

PY2 = sys.version_info[0] == 2

VERSION = ''

if PY2:
    with open('zyqconf/__init__.py', 'r') as fd:
        VERSION = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]',
                            fd.read(), re.MULTILINE).group(1)
else:
    with open('zyqconf/__init__.py', 'r', encoding='utf-8') as fd:
        VERSION = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]',
                            fd.read(), re.MULTILINE).group(1)


if not VERSION:
    raise RuntimeError('Cannot find version information')

packages, data_files = [], []


def fullsplit(path, result=None):
    """
    Split a pathname into components (the opposite of os.path.join) in a
    platform-neutral way.
    """
    if result is None:
        result = []
    head, tail = os.path.split(path)
    if head == '':
        return [tail] + result
    if head == path:
        return result
    return fullsplit(head, [tail] + result)


def is_not_module(filename):
    """check filename
    """
    return os.path.splitext(filename)[1] not in ['.py', '.pyc', '.pyo']

for zyqconf_dir in ['zyqconf']:
    for dirpath, dirnames, filenames in os.walk(zyqconf_dir):
        # Ignore dirnames that start with '.'
        for i, dirname in enumerate(dirnames):
            if dirname.startswith('.'):
                del dirnames[i]
        if '__init__.py' in filenames:
            packages.append('.'.join(fullsplit(dirpath)))
            data = [f for f in filenames if is_not_module(f)]
            if data:
                data_files.append(
                    [dirpath, [os.path.join(dirpath, f) for f in data]])
        elif filenames:
            data_files.append(
                [dirpath, [os.path.join(dirpath, f) for f in filenames]])
    data_files.append(['.', ['README.rst']])

print(data_files)

setup(
    name='zyqconf',
    version=VERSION,
    packages=packages,
    description='higher level QConf client',
    author='wanglicaho',
    author_email='wanglichao@zhangyue.com',
    data_files=data_files,
)
