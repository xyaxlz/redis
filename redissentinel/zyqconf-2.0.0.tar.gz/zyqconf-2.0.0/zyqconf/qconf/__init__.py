import sys
import traceback

PY2 = sys.version_info[0] == 2

try:
    if PY2:
        from zyqconf.qconf.py2 import qconf_py
    else:
        from zyqconf.qconf.py3 import qconf_py
except Exception:
    print("Failed to import qconf_py!\n{0}".format(traceback.format_exc()))

__all__ = ["qconf_py"]
