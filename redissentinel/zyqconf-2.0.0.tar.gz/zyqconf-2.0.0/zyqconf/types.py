# -*- coding: utf-8 -*-
'''
Copyright (c) 2017,掌阅科技
All rights reserved.

File Name: types.py
Author: baijiangtao
Created on: 2017-07-20
'''

import os
import sys
import traceback
import logging
import yaml

from zyqconf import hooks
from zyqconf.qconf import qconf_py

# zookeeper节点上存储字典和列表数据结构所使用的特殊节点值
DICT_SYMBOL = "DICT_ZNODE"
LIST_SYMBOL = "LIST_ZNODE"

# 获取配置失败时的钩子名称
HOOK_CONF_ERROR = "zyqconf.conf_error"

# Set default logging handler to avoid "No handlers could be found
# for logger" warning, taken from peewee
try:  # Python 2.7+
    from logging import NullHandler
except ImportError:
    class NullHandler(logging.Handler):
        """null handler
        """

        def emit(self, record):
            pass

logger = logging.getLogger('zyqconf')
logger.addHandler(NullHandler())

def ensure_string(s):
    """ 确保返回的为所有元素都是string类型
    """
    if isinstance(s, dict):
        return {ensure_string(k):ensure_string(v) for k, v in s.items()}
    if isinstance(s, list):
        return [ensure_string(item) for item in s]
    if hasattr(s, 'decode'):
        return s.decode()
    else:
        return s

def deserialize(data):
    """反序列化zookeeper节点数据
    """
    value = ""
    try:
        value = yaml.load(data)
    except Exception:
        exc_info = "Error occurred while deserializing data: {0}\n{1}".format(
            data, traceback.format_exc())
        logger.warning(exc_info)
        value = data
    return value


def serialize(data):
    """序列化zookeeper节点数据
    """
    return yaml.dump(data)


def quote_key(key):
    """特殊字符'/'转义处理
    """
    key = ensure_string(key)
    return key.replace('/', '%2F')

def unquote_key(key):
    """特殊字符'/'反转义处理
    """
    key = ensure_string(key)
    return key.replace('%2F', '/')

def qconf_get_batch_keys(path, idc=''):
    """重写qconf_py.get_batch_keys函数，增加idc的判断
    """
    return qconf_py.get_batch_keys(path, idc)

def specific_deserialize(data):
    """尝试反序列化(历史遗留原因!!!)
    """
    try:
        value = yaml.load(data)
        # dirty hack
        if value is None or isinstance(value, (dict, list, bool)):
            value = data
        if str(value) == data:
            value = data
    except Exception as exc:
        value = data
    return value


class QconfNode(object):
    """Zookeeper节点的基础封装
    """

    def __init__(self, parent_path, idc='', is_deserialize=False):
        self.parent_path = parent_path
        self.idc = idc
        self.is_deserialize = is_deserialize

    def __getattr__(self, key):
        """重载点运算符
        """
        # 忽略python中的魔术属性
        if key.startswith("__"):
            return
        path = self.join_path(self.parent_path, key)
        return self.get_conf(path, idc=self.idc)

    def join_path(self, path_name, file_name):
        """拼接节点路径，转义字符'/'需要特殊处理，避免zookeeper产生歧义
        """
        file_name = quote_key(file_name)
        return os.path.join(path_name, file_name)

    def get_conf(self, path, idc='', silent=False):
        """通过qconf获取给定路径的节点数据
        """
        conf = None
        try:
            value = qconf_py.get_conf(path, idc)
            if value:
                # 反序列化
                value = deserialize(value)
                value = ensure_string(value)
        except qconf_py.Error:
            exc_info = "Could not get conf from path: {0}\n{1}".format(
                path, traceback.format_exc())
            logger.warning(exc_info)
            if not silent:
                hooks.get_hook(HOOK_CONF_ERROR).send(
                    path=path, exc_info=exc_info)
        else:
            if value == DICT_SYMBOL:
                conf = DictNode(path)
            elif value == LIST_SYMBOL:
                conf = ListNode(path)
            else:
                conf = value
        return conf

    def get_value(self):
        """获取节点值
        """
        value = ''
        try:
            value = qconf_py.get_conf(self.parent_path, self.idc)
            if value:
                # 反序列化
                if self.is_deserialize:
                    value = specific_deserialize(value)
                else:
                    value = deserialize(value)
        except qconf_py.Error:
            exc_info = "Error occurred while getting value for path: {0}\n{1}".format(
                self.path, traceback.format_exc())
            logging.error(exc_info)
        return ensure_string(value)

    def get_child_keys(self):
        """获取子节点的key的列表
        """
        keys = []
        try:
            keys = qconf_py.get_batch_keys(self.parent_path, self.idc)
        except qconf_py.Error:
            logging.info("Failed to find the key on given idc, path=%s, idc=%s",
                self.parent_path, self.idc)
        return ensure_string(keys)


class ListNode(QconfNode):
    """在Zookeeper普通节点上模拟出python列表(list)常用方法
    """

    def __init__(self, path, idc=''):
        super(ListNode, self).__init__(path, idc=idc)

    def __getitem__(self, index):
        path = self.join_path(self.parent_path, str(index))
        item = self.get_conf(path, idc=self.idc)
        if item is None:
            raise IndexError
        return item

    def __len__(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        return len(keys)

    def __iter__(self):
        """迭代器协议实现
        """
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            path = self.join_path(self.parent_path, key)
            yield self.get_conf(path, self.idc)

    def __repr__(self):
        list_repr = []
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in sorted(keys):
            key = ensure_string(key)
            list_repr.append(self[key])
        return repr(list_repr)

    def as_list(self):
        """递归获取列表所有数据
        """
        list_obj = []
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in sorted(keys):
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            value = node = self.get_conf(path, self.idc)
            if isinstance(node, DictNode):
                value = node.as_dict()
            elif isinstance(node, ListNode):
                value = node.as_list()
            list_obj.append(value)
        return list_obj


class DictNode(QconfNode):
    """在Zookeeper普通节点上模拟出python字典(dict)常用方法

    说明：
        DictNode仅支持以*字符串*作为key值

    """

    def __init__(self, path, idc=''):
        super(DictNode, self).__init__(path, idc=idc)

    def __getitem__(self, key):
        path = self.join_path(self.parent_path, str(key))
        item = self.get_conf(path, self.idc)
        if item is None:
            raise KeyError(key)
        return item

    def __iter__(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            yield unquote_key(key)

    def __len__(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        return len(keys)

    def __eq__(self, dict_obj):
        if len(self) != len(dict_obj):
            return False
        for key, value in dict_obj.iteritems():
            if key not in self or self[key] != value:
                return False
        return True

    def __contains__(self, key):
        keys = self.keys()
        return str(key) in keys

    def __repr__(self):
        dict_repr = {}
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            dict_repr[key] = self.get_conf(path, idc=self.idc)
        return repr(dict_repr)

    def get(self, key, default=None):
        if str(key) in self.keys():
            # dirty hack for unknown error
            path = self.join_path(self.parent_path, str(key))
            value = self.get_conf(path, idc=self.idc, silent=True)
            if value is None:
                logger.warning(
                    "Error occurred while getting conf from path: [%s], using default value", path)
                return default
            else:
                return value
        else:
            return default

    def keys(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        return [unquote_key(key) for key in keys]

    def items(self):
        items = []
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            items.append((key, self.get_conf(path, self.idc)))
        return items

    def iteritems(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            yield (key, self.get_conf(path, self.idc))

    def itervalues(self):
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            yield self.get_conf(path, self.idc)

    def as_dict(self):
        """递归获取字典所有数据
        """
        dict_obj = {}
        keys = qconf_get_batch_keys(self.parent_path, self.idc)
        for key in keys:
            key = ensure_string(key)
            path = self.join_path(self.parent_path, key)
            value = node = self.get_conf(path, self.idc)
            if isinstance(node, DictNode):
                value = node.as_dict()
            elif isinstance(node, ListNode):
                value = node.as_list()
            dict_obj[key] = value
        return dict_obj
