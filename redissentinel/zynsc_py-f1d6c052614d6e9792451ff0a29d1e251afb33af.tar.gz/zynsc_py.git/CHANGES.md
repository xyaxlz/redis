### 版本变更说明
---
#### v0.1.0
* 实现get_service层基础接口
* 实现基础算法选择服务
* 实现接入zkapi和qconf

#### v0.9.5

* 新增获取当前项目是否可以消费rabbitmq相关接口:`is_consumer_ok`, 接口返回True表示允许消费，接口返回False表示不允许消费
