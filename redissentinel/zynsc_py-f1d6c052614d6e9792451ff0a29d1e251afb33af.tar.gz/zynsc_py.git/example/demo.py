#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
demo
~~~~~~~~~~~~

测试zynsc

:copyright: (c) 2018 zhangyue
:authors: wanglichao
:version: 1.0 of 2018-03-28

"""
# pylint: disable=all
import time
import sys
import re
import zynsc
from zynsc import NSClient

regex = re.compile(r"^arch\.(\w+)\.tcp")

nsc = NSClient.instance().init(port=8899)


def demo():
    services = nsc.get_service("arch.archapi_mysql.tcp")
    print(services)
    idc = nsc.get_namespace_idc("arch.archapi_mysql.tcp")
    print(idc)
    cat_services = nsc.get_service("arch.cat_mysql.tcp")
    print(cat_services)
    namespaces = nsc.get_namespaces()
    print(namespaces)
    namespaces = nsc.get_namespaces(regex=regex)
    print(namespaces)
    config = nsc.get_namespace_config("arch.archapi_mysql.tcp")
    print(config)

def is_consumer_ok():
    ret = zynsc.is_consumer_ok()
    print(ret)

if __name__ == '__main__':
    demo()
    is_consumer_ok()
