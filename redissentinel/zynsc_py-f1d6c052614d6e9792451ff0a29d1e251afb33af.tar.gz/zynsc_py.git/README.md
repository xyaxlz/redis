## 简介
---
zynsc 是zhangyue name service client的缩写
zynsc_py 是名字服务python版本的含义

## 名字服务python client使用说明
---
### [项目地址](http://192.168.6.70/architecture/zynsc_py)

### 安装方法
1. git clone http://192.168.6.70/architecture/zynsc_py
2. cd zynsc_py
3. pip install -r requirements.txt
4. python setup.py install

### 项目配置说明
* zk_prefix：用来配置zookeeper前缀
* zkapi_path: zkapi的服务提供者路径
* zkapi_add_consumer: 服务消费者接口路径

### 接口使用

接口使用前需要优先进行初始化，对象初始化方法:
备注：该配置项理论上不需要调整，默认的即为正确的配置

```python
>>> from zynsc import NSClient
>>> config = {
>>> "zk_prefix": "arch_group/zkapi",  # 全局前缀设置
>>> "zkapi_path": "/arch_group/zkapi/arch.zkapi.http/providers", # zkapi服务配置
>>> "zkapi_add_consumer": "/v1/zkapi/consumers/{namespace}/{consumer}" } # 消费者模板配置
>>> nsc = NSClient.instance().init("4455", config) # 消费者可以不用注册
```

或者使用简化版本的初始化方式

```python
>>> from zynsc import NSClient # 简化初始化版本
>>> nsc = NSClient.instance().init()  # 其中端口和config可以不传递
>>> nsc.unregister_all()   # 当进程退出时执行该逻辑避免消费者关联关系不确定
```

#### get_services接口
* 接口名称: get_services
* 接口描述：获取服务提供者列表
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
    * type namespace: str
* 接口返回值说明
	* 返回服务列表
* get_services接口使用举例

```python
>>> services = nsc.get_services("arch.zkapi.http")
>>> services
[192.168.40.82:10002, 192.168.6.71:19992, 192.168.6.7:1999]
```

#### get_service接口
* 接口名称: get_service
* 接口描述：获取服务提供者逻辑
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
	* namespace: str
	* algorithm (optional): 算法选择,参数非必选,默认为随机
	* algorithm: AlgorithmType
	* default (optional): 构造的service对象
	* default: :class:`Service <Service>` object
	* uri (optional): 期望获取的uri地址,算法模块会根据该参数进行最长匹配模式选择和uri匹配度最高的service返回
	* uri: str
* 接口返回值说明
	* 返回Service对象
* get_service接口使用举例

```python
>>> service = nsc.get_service("cps.newcps.http")
>>> service.to_dict()
{"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/", "idc": "m5", "disable": 0}
```

#### get_master_service接口
* 接口名称: get_master_service
* 接口描述：获取服务提供者逻辑,用于获取区分主从的服务的主服务
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
	* namespace: str
	* algorithm (optional): 算法选择,参数非必选,默认为随机
	* algorithm: AlgorithmType
	* default (optional): 构造的service对象
	* default: :class:`Service <Service>` object
* 接口返回值说明
	* 返回Service对象
* get_master_service接口使用举例

```python
>>> service = nsc.get_master_service("cps.newcps.http")
>>> service.to_dict()
{"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/master"}
```

#### get_slave_service接口
* 接口名称: get_slave_service
* 接口描述：获取服务提供者逻辑,用于获取区分主从的服务的从服务
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
	* namespace: str
	* algorithm (optional): 算法选择,参数非必选,默认为随机
	* algorithm: AlgorithmType
	* default (optional): 构造的service对象
	* default: :class:`Service <Service>` object
* 接口返回值说明
	* 返回Service对象列表
* get_slave_service接口使用举例

```python
>>> service = nsc.get_slave_service("cps.newcps.http")
>>> service
[{"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/slave"}, {"host": "192.168.4.2", "port": 4455, "weight": 1, "uri": "/slave"}]
```

#### get_slow_service接口
* 接口名称: get_slow_service
* 接口描述：获取服务提供者逻辑,用于获取区分快慢的接口的慢接口
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
	* namespace: str
	* algorithm (optional): 算法选择,参数非必选,默认为随机
	* algorithm: AlgorithmType
	* default (optional): 构造的service对象
	* default: :class:`Service <Service>` object
* 接口返回值说明
	* 返回Service对象
* get_slow_service接口使用举例

```python
>>> service = nsc.get_slow_service("cps.newcps.http")
>>> service.to_dict()
{"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/slow"}
```

#### get_namespace_idc接口
* 接口名称: get_namespace_idc
* 接口描述：获取名字空间提供服务的机房
* 接口参数说明
	* namespace: 名字空间,{group}_{service}_{type}
	* namespace: str
* 接口返回值说明
	* 返回机房名称
* get_namespace_idc接口使用举例

```python
>>> idc = nsc.get_namespace_idc("cps.newcps.http")
>>> idc
m5
```


#### get_current_idc接口
* 接口名称：get_current_idc
* 接口描述：获取当前机房名称
* 接口参数：无
* 接口返回说明：返回机房名称
* get_current_idc 使用举例

```python
>>> import zynsc
>>> idc = zynsc.get_current_idc()
>>> idc
m5
```

#### get_current_project接口
* 接口名称：get_current_project
* 接口描述：获取当前服务所属项目
* 接口参数：无
* 接口返回说明：返回项目名称
* get_current_project 使用举例

```python
>>> import zynsc
>>> project = zynsc.get_current_project()
>>> project
architecture/zynsc
```
#### get_current_namespace接口
* 接口名称：get_current_namespace
* 接口描述：获取当前服务所属名字空间
* 接口参数：无
* 接口返回说明：返回名字空间名称
* get_current_namespace使用举例

```python
>>> import zynsc
>>> ns = zynsc.get_current_namespace()
>>> ns
arch.archapi.http
```

#### is_consumer_ok接口
* 接口名称：is_consumer_ok
* 接口描述：判定当前项目是否可以消费rabbitmq
* 接口参数：无
* 接口返回说明：True or False
* is_consumer_ok使用举例

```python
>>> import zynsc
>>> ok_flag = zynsc.is_consumer_ok()
>>> ok_flag
True
```


#### register_by_human接口
* 接口名称：register_by_human
* 接口描述：手工注册业务方依赖的其他名字空间
* 接口参数：namespaces列表
* 接口返回说明：无
* 使用举例

```python
>>> import zynsc
>>> zynsc.register_by_human(["arch.archapi_mysql.tcp", "arch.archapi_codis.tcp"])
```


### 算法模块说明
* random
随机选择一个服务提供者
* weight_random
加权随机，会根据服务提供者的权重进行加权随机
* source_hashing
基于源站的哈希算法来选择服务提供者,每个服务器获取的服务提供者都是固定的
* local_first
加权随机获取服务，但是当存在本机服务信息时候优先使用本机提供的服务
* uri_service
返回指定uri的服务列表，默认所有的名字空间的uri均为"/"，除非特殊指定uri

## 版本变更说明

* v0.9.6

> 1. 取消项目所在机房验证，只验证开关逻辑

* v0.9.7

> 1. python2没有增加utf-8注释问题修复
