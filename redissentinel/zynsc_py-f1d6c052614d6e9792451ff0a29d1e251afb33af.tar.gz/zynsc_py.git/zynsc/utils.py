# -*- coding: utf-8 -*-

"""
uitls
~~~~~~~~~~~~

公用模块

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-24

"""
import sys
import os
import json
import socket
import logging
import threading
import functools
import traceback
import struct
import fcntl

__LOCALHOST = None

PY2 = sys.version_info[0] == 2

logger = logging.getLogger("zynsc")


def get_env(env_name):
    """从环境变量获取配置
    """
    return os.environ.get(env_name, "")


def get_host_by_network():
    """获取本机IP
    """
    return [
        (s.connect(('10.100.20.32', 53)),
         s.getsockname()[0],
         s.close()) for s in [socket.socket(
             socket.AF_INET,
             socket.SOCK_DGRAM
         )]
    ][0][1]


def get_host(ifname=None):
    """获取服务器IP地址
    """
    global __LOCALHOST
    if __LOCALHOST:
        return __LOCALHOST
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    retry_ifnames = ["bond0", "team0", "eth0"]  # 最常用的三种网卡命名方式
    if ifname and ifname not in retry_ifnames:
        retry_ifnames.insert(0, ifname)
    local_ip = None
    max_retry_times = len(retry_ifnames)
    for retry_time, ifname_ in enumerate(retry_ifnames, 1):
        try:
            if PY2:
                local_ip = socket.inet_ntoa(fcntl.ioctl(
                    sock.fileno(),
                    0x8915,  # SIOCGIFADDR
                    struct.pack('256s', ifname_[:15])
                )[20:24])
            else:
                local_ip = socket.inet_ntoa(fcntl.ioctl(
                    sock.fileno(),
                    0x8915,  # SIOCGIFADDR
                    struct.pack('256s', bytes(ifname_[:15], "utf-8"))
                )[20:24])
            break
        except IOError as err:
            # errno = 19 means no such device
            if retry_time == max_retry_times and err.errno != 19:
                logger.error("get_ip_addr failed, error=%s", err)
    if not local_ip:
        local_ip = get_host_by_network()
    __LOCALHOST = local_ip
    return local_ip


class SingletonMixin(object):

    """Based on tornado.ioloop.IOLoop.instance() approach.
    参考：https://github.com/facebook/tornado
    """
    __singleton_lock = threading.Lock()
    __singleton_instance = None

    @classmethod
    def instance(cls):
        """给单例类增加入口
        """
        if not cls.__singleton_instance:
            with cls.__singleton_lock:
                if not cls.__singleton_instance:
                    cls.__singleton_instance = cls()
        return cls.__singleton_instance


EXCEPT_RETURN = {}


def if_exception_return(ex_type, cache_key_pos=0, expect_ret=None):
    """针对异常ex_type信息进行捕获,如果发生指定异常返回,异常后如果存在上次成功记录就返回上次成功时候的值
    否则返回None
    使用指定cache_key的方式避免计算哈希的开销
    :param ex_type: 异常类
    :param cache_key_pos: 指定使用哪个列表字段做为缓存的KEY,如果kwargs指定了cache_key则优先级高
    :return: 正常函数执行结果或者返回参数中的default值
    """
    def decorator(func):
        """对func进行装饰
        """
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            """ 截获异常ex_type返回then_result
            """
            if "cache_key" in kwargs:
                cache_key = kwargs["cache_key"]
            else:
                cache_key = args[cache_key_pos]
            try:
                # 记录上次成功的返回值,如果异常返回上次成功的值
                last_success = func(*args, **kwargs)
                EXCEPT_RETURN[cache_key] = last_success
                return last_success
            except ex_type:
                default = kwargs.get("default")
                if default is not None:
                    EXCEPT_RETURN[cache_key] = default
                else:
                    EXCEPT_RETURN[cache_key] = expect_ret
                logger.error(
                    "exec %s, error=%s",
                    func.__name__,
                    traceback.format_exc())
                return EXCEPT_RETURN[cache_key]
        return wrapper
    return decorator


def get_diff_conf(current_conf, new_conf):
    """获取变更的配置项

    :param current_conf: 当前配置
    :type current_conf: dict
    :param new_conf: 旧配置
    :type new_conf: dict
    :return: 新增，删除，修改，相同的key列表
    :rtype: tuple([], [], [], [])
    """
    added, removed, modified, same = [], [], [], []
    current_conf_keys = set(current_conf.keys())
    new_conf_keys = set(new_conf.keys())
    added = list(new_conf_keys - current_conf_keys)
    removed = list(current_conf_keys - new_conf_keys)
    shared_keys = list(new_conf_keys & current_conf_keys)
    for key in shared_keys:
        nval = new_conf[key]
        cval = current_conf[key]
        if nval != cval:
            modified.append(key)
        else:
            same.append(key)
    return added, removed, modified, same

def ensure_string(s):
    """ 确保返回的为所有元素都是string类型
    """
    if isinstance(s, dict):
        return {ensure_string(k):ensure_string(v) for k, v in s.items()}
    if isinstance(s, list):
        return [ensure_string(item) for item in s]
    if hasattr(s, 'decode'):
        return s.decode()
    else:
        return s

def safe_json_loads(config):
    """解析zk中的json配置
    :param config: 配置信息
    :rtype: dict
    """
    if not config:
        return {}
    try:
        if PY2:
            config = json.loads(config)
        else:
            if isinstance(config, str):
                config = json.loads(config)
            else:
                config = json.loads(config.decode("utf8"))
    except ValueError:
        config = {}
    return config
