# -*- coding: utf-8 -*-
"""
__init__
~~~~~~~~~~~~

please add description for this module

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""

from zynsc.client import NSClient
from zynsc.algorithms import AlgorithmType
from zynsc.name_service import Service
from zynsc.config import CONFIG
from zynsc.client import (
    get_ns,
    get_current_idc,
    get_current_project,
    get_current_namespace,
    is_consumer_ok,
)
from zynsc.common_nsc_manager import (
    NSCFilter,
    ClientConfig,
    Client,
    ClientPool,
    CommonNSCManager,
)

__version__ = "0.9.8"

__all__ = [
    "NSClient",
    "AlgorithmType",
    "Service",
    "CONFIG",
    "get_ns",
    "get_current_idc",
    "get_current_project",
    "get_current_namespace",
]
