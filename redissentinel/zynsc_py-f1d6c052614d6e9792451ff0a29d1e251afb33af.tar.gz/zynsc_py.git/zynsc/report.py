# -*- coding: utf-8 -*-

"""
report
~~~~~~~~~~~~

统一负责消息上报逻辑

:copyright: (c) 2019 zhangyue
:authors: wanglichao
:version: 1.0 of 2019-08-22

"""
import time
import json
import socket

class Reporter(object):

    """ 基础依赖关系通过UDP上报
    """

    host = "127.0.0.1"
    port = 4458
    interval = 300  # 间隔时间
    protocol = "{topic}|{msg_type}|{msg_body}"
    udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP
    topic = "name_service_consumer"
    msg_type = "json"
    update_time = None

    def __init__(self, host="127.0.0.1", port=4458, interval=300):
        self.host = host
        self.port = port
        self.interval = interval

    def set_msg_type(self, msg_type):
        """更新消息类型
        """
        self.msg_type = msg_type
        return self

    def set_topic(self, topic):
        """设置服务类型
        """
        self.topic = topic
        return self

    def is_interval_ok(self):
        """检查间隔
        """
        if self.update_time is None:
            return True
        current_time = time.time()
        return (current_time - self.update_time) > self.interval

    def build_payload(self, msg_body):
        """ 构造消息体,目前支持纯文本和json两种
        """
        if self.msg_type == "json":
            msg_body = json.dumps(msg_body)
        payload = self.protocol.format(
            topic=self.topic,
            msg_type=self.msg_type,
            msg_body=msg_body,
        )
        return payload.encode("utf-8")

    def report(self, msg_body):
        """ 发送UDP包给本机agent
        """
        if not self.is_interval_ok():
            return
        self.update_time = time.time()
        self.udp_client.sendto(self.build_payload(msg_body), (self.host, self.port))
