# -*- coding: utf-8 -*-

"""
errors
~~~~~~~~~~~~

错误类型封装

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""


class ZYNSCError(Exception):
    """基础错误类型
    """
    pass


class ConfigError(ZYNSCError):
    """配置错误
    """
    pass


class NotFoundError(ZYNSCError):
    """找不到节点
    """
    pass
