#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_name_service
~~~~~~~~~~~~

测试name service相关函数

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-24

"""
# pylint: disable=all
import pytest

from zynsc.name_service import NameService


def test_name_service():
    """测试名字服务
    """
    config = {
        "zk_prefix": "arch_group/zkapi",
        "zkapi_path": "/arch_group/zkapi/arch.zkapi.http/providers",
        "zkapi_add_consumer": "/v1/zkapi/consumers/{namespace}/{consumer}"
    }
    ns = NameService(config)

    providers = ns.get_providers("cps.content.http")
    assert isinstance(providers, list)
    services = ns.get_services("cps.content.http")
    assert isinstance(services, list)
    service_dict = services[0].to_dict()
    assert "host" in service_dict
    assert "port" in service_dict
    assert "uri" in service_dict
