# -*- coding: utf-8 -*-

"""
handler
~~~~~~~~~~~~

desc

:copyright: (c) 2019 zhangyue
:authors: HuZilin
:version: 1.0 of 2019-09-24

"""

import sys
import platform
import socket
import json

import time

from zyqconf import qconf_py
from zynsc import utils
from zynsc.config import CONFIG
from zynsc.sentryhandler.serializer import Serializer
from zynsc.sentryhandler.utils import exc_info_from_error, event_from_exception

# pylint: disable=bad-continuation


class Event:
    """Sentry Event
    """

    udp_host = "127.0.0.1"
    udp_port = 4458
    protocol = "sentry|json|{msg_body}"
    udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP

    host = utils.get_host()
    port = utils.get_env(CONFIG.get("port_env_name", "ZYAGENT_HTTPPORT"))
    idc = utils.ensure_string(qconf_py.get_conf("/arch_group/idc/current"))
    namespace = utils.get_env("NAMESPACE")
    project = utils.get_env("PROJECT_NAME")
    language = "Python"
    language_version = "python " + platform.python_version()

    def __init__(self, error, level=None):
        self.__event = None

        if isinstance(error, str):
            self.__capture_message(message=error, level=level)
        elif isinstance(error, Exception):
            self.__capture_exception(error)
        self.__event["tags"] = {
            "idc": self.idc,
            "ip": self.host,
            "port": self.port,
            "namespace": self.namespace,
            "project": self.project,
            "language": self.language,
            "language_version": self.language_version,
        }

    def __capture_message(
        self,
        message,  # type: str
        level=None,  # type: Optional[str]
    ):
        # type: (...) -> Optional[str]
        """Captures a message.  The message is just a string.  If no level
        is provided the default level is `info`.

        :returns: An `event_id` if the SDK decided to send the event (see :py:meth:`sentry_sdk.Client.capture_event`).
        """
        if level is None:
            level = "info"
        event = {"message": message, "level": level}
        self.__event = self.__prepare_event(event, None, None)

    def __capture_exception(
        self, error=None  # type: Optional[Union[BaseException, ExcInfo]]
    ):
        # type: (...) -> Optional[str]
        """Captures an exception.

        :param error: An exception to catch. If `None`, `sys.exc_info()` will be used.

        :returns: An `event_id` if the SDK decided to send the event (see :py:meth:`sentry_sdk.Client.capture_event`).
        """
        if error is None:
            exc_info = sys.exc_info()
        else:
            exc_info = exc_info_from_error(error)

        event, hint = event_from_exception(exc_info)

        self.__event = self.__prepare_event(event, hint, None)

    @staticmethod
    def __prepare_event(
        event,  # type: Event
        hint,  # type: Optional[Hint]
        scope,  # type: Optional[Scope]
    ):
        # type: (...) -> Optional[Event]
        if event.get("timestamp") is None:
            event["timestamp"] = int(time.time())

        hint = dict(hint or ())  # type: Hint

        if scope is not None:
            event_ = scope.apply_to_event(event, hint)
            if event_ is None:
                return None
            event = event_

        if event.get("platform") is None:
            event["platform"] = "python"

        # Postprocess the event here so that annotated types do
        # generally not surface in before_send
        if event is not None:
            event = Serializer().serialize_event(event)

        return event

    def set_tag(self, key, value):
        """set tag on event
        """
        if self.__event.get("tags") is None:
            self.__event["tags"] = {}
        self.__event["tags"][key] = value
        return self

    def __build_payload(self):
        """ 构造消息体
        """
        msg_body = json.dumps(self.__event)
        payload = self.protocol.format(msg_body=msg_body)
        return payload.encode("utf-8")

    def report(self):
        """ 发送UDP包给本机agent
        """
        self.udp_client.sendto(
            self.__build_payload(), (self.udp_host, self.udp_port)
        )
