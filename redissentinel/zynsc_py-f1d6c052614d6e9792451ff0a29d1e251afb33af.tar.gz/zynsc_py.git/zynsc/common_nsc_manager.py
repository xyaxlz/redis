# -*- coding: utf-8 -*-

"""
common_nsc_manager
~~~~~~~~~~~~

通用的服务发现管理层

:copyright: (c) 2018 zhangyue
:authors: wanglichao
:version: 1.0 of 2018-03-22

"""
# pylint: disable=too-many-arguments,too-many-locals
import random
try:
    from zyqconf.qconf import qconf_py as qconf
except ImportError:
    pass

from zynsc.client import NSClient
from zynsc.utils import SingletonMixin
from zynsc.cachetools import TTLCache
from zynsc.errors import ConfigError
from zynsc.utils import logger
from zynsc.utils import get_diff_conf
from zynsc.sentryhandler.handler import Event

# RRLCache的最多存储keys的个数
MAXSIZE = 100
# RRLCache的key的超时时间
TTL = 10


class NSCFilter(object):
    """通用的筛选器，用于统一生成拿各种配置的规则
    """
    __filter_uniq_tpl = "{namespace}:{uri}?kind={kind}&{extra_kv}"
    __filter_instance_tpl = "{namespace}:{kind}/{extra_kv}"

    def __init__(self, namespace, kind, uri, **kwargs):
        """
        :param namespace: 名字空间
        :param kind: 对应对象类型，比如：peewee,mysqldb,database
        :param uri: 名字空间中host,port的过滤条件，比如：/master,/slave
        :param kwargs: 扩展过滤属性,比如数据库中一个库对应多个db名称
        """
        self.namespace = namespace
        self.kind = kind
        self.uri = self.ensure_with_slash(uri)
        if kwargs:
            self.extra_kv = "&".join(["{}={}".format(k, v)
                                      for k, v in kwargs.items()])
        else:
            self.extra_kv = ""

    @property
    def instance_key(self):
        """生成获取实例的规则
        """
        return self.__filter_instance_tpl.format(
            namespace=self.namespace,
            kind=self.kind,
            extra_kv=self.extra_kv,
        )

    def make_uniq_key(self, uri=""):
        """生成filter过滤规则
        :param uri: uri为可变配置项，不同uri的配置可能一样
        """
        if not uri:
            uri = self.uri
        return self.__filter_uniq_tpl.format(
            namespace=self.namespace,
            kind=self.kind,
            uri=uri,
            extra_kv=self.extra_kv,
        )

    @staticmethod
    def ensure_with_slash(uri):
        """确保以/开头
        """
        if uri.startswith("/"):
            return uri
        return "/" + uri

    def __str__(self):
        return self.make_uniq_key()

    def __repr__(self):
        return self.make_uniq_key()


class ClientConfig(object):  # pylint: disable=too-few-public-methods
    """对象配置
    """

    def __init__(self, nsc_filter, config):
        """用于记录对象的配置信息
        :param nsc_filter: 过滤器
        :param config: 配置信息
        """
        self.nsc_filter = nsc_filter
        self.config = config

    def string(self):
        """字符串描述
        """
        return "ClientConfig: nsc_filter={},config={}".format(
            self.nsc_filter,
            self.config)

    def __str__(self):
        return self.string()

    def __repr__(self):
        return self.string()


class Client(object):
    """通用的client对象
    """

    def __init__(self, host, port, nsc_filter, client_instance, uri="/", weight=1, need_close=True):  # pylint:disable=too-many-arguments
        """
        :param client_instance: 外部生成的对象
        :param weight: 权重
        :param need_close: 是否需要关闭
        :param uri: uri
        :param nsc_filter: 用于额外过滤的参数
        :type nsc_filter: `NSCFilter`
        """
        self.host = host
        self.port = port
        self.weight = weight
        self.need_close = need_close
        self.uri = uri
        self.client_instance = client_instance
        self.nsc_filter = nsc_filter

    @property
    def kind(self):
        """客户端类型
        """
        return self.nsc_filter.kind

    @property
    def instance(self):
        """获取对象实例
        """
        return self.client_instance

    @property
    def key(self):
        """唯一性描述
        """
        uniq_key = self.nsc_filter.make_uniq_key(self.uri)
        return "{}:{}?weight={}&need_close={}|{}".format(
            self.host,
            self.port,
            self.weight,
            self.need_close,
            uniq_key,
        )

    def string(self):
        """生成日志使用
        """
        return "Client: weight={},nsc_filter={}".format(self.weight, self.nsc_filter.make_uniq_key())

    def __str__(self):
        return self.string()

    def __repr__(self):
        return self.key

    def __eq__(self, other):
        """用于相等比较
        """
        return self.key == other.key

    def __hash__(self):
        """用于生成唯一性哈希值，支持内置hash函数
        """
        return hash(self.key)


class ClientPool(object):
    """连接池对象
    """

    def __init__(self, nsc_filter, client_instance):
        self.nsc_filter = nsc_filter
        self.client_instance = client_instance

    @property
    def instance(self):
        """返回连接池实例
        """
        return self.client_instance

    @property
    def kind(self):
        """客户端类型
        """
        return self.nsc_filter.kind


class CommonNSCManager(SingletonMixin):

    """通用的服务发现管理模块
    """
    # 记录所有的filters对象
    filters_record = {}
    filter_pool_record = {}
    # 记录名字空间以及其对应的配置,instance_key <=> config
    namespaces_config = {}

    # 记录所有的key对应的对象, instance_key <=> instance * weight
    clients_manager = {}
    client_pool_manager = {}
    # 记录名字空间对应的对象以及其对应的配置,uniq_key <=> config
    clients_config = {}

    # 带有时间周期的本地缓存
    ttl_cache = TTLCache(maxsize=MAXSIZE, ttl=TTL)
    zynsc_cli = None

    # 已添加job标记
    add_job_flag = False
    scheduler = None

    def __call__(self):
        """周期性执行
        """
        logger.info("exec period_check")
        for nsc_filter in self.filters_record.values():
            self.get_client(nsc_filter)
        for nsc_filter in self.filter_pool_record.values():
            self.get_client_pool(nsc_filter)

    def init(self, *conf):
        """总的初始化入口
        :param conf: 客户端配置`ClientConfig`对象列表
        :type conf: list
        """
        if not self.zynsc_cli:
            self.zynsc_cli = NSClient().init()
        # 记录客户端传递过来的所有配置信息
        for client_config in conf:
            nsc_filter = client_config.nsc_filter
            # client 配置信息之所以用uniq_key是因为数据库主从可能配置不一样
            # 最好全局保留不同的配置信息
            self.clients_config[
                nsc_filter.make_uniq_key()] = client_config.config
        return self

    def start_period_check(self, seconds=TTL):
        """启动任务
        """
        if not self.add_job_flag:
            try:
                from apscheduler.schedulers.tornado import TornadoScheduler
                self.scheduler = TornadoScheduler()
                logger.warning("add auto check job")
                self.scheduler.add_job(self, "interval", seconds=seconds)
                self.add_job_flag = True
                self.scheduler.start()
            except ImportError as error:
                Event(error).report()
                logger.error("no task were running, error=%s", error)

    def get_client_pool(self, nsc_filter):
        """获取对象池
        """
        if self.was_changed(nsc_filter):
            logger.warning(
                "exec get_client, conf was changed, nsc_filter=%s", nsc_filter)
            self.update_client_pool(nsc_filter)
        instance_key = nsc_filter.instance_key
        client_pool = self.client_pool_manager.get(instance_key, None)
        if not client_pool:
            raise ConfigError(
                "exec get_client_pool failed, nsc_filter=%s", nsc_filter)

        if instance_key not in self.filter_pool_record:
            self.filter_pool_record[instance_key] = nsc_filter

        return client_pool.instance

    def update_client_pool(self, nsc_filter):
        """更新对象连接池
        """
        namespace = nsc_filter.namespace
        instance_key = nsc_filter.instance_key
        current_config = self.namespaces_config.get(instance_key, {})
        new_config = self.get_config(namespace)
        new, removed, modified, same = get_diff_conf(
            current_config, new_config)
        logger.warning(("exec update_clients, instance_key=%s, new=%s,"
                        "removed=%s, modified=%s, same=%s"),
                       instance_key, new, removed, modified, same)
        new_namespace_config = self.get_config(namespace)
        client_pool = self.construct_client_pool(
            nsc_filter, new_namespace_config)
        self.client_pool_manager[instance_key] = client_pool
        self.namespaces_config[instance_key] = new_namespace_config

    def get_client(self, nsc_filter):
        """通过服务发现方式动态获取对象
        :param nsc_filter: 基于过滤器进行筛选
        """
        # 检查服务发现是否有配置变更
        if self.was_changed(nsc_filter):
            logger.warning(
                "exec get_client, conf was changed, nsc_filter=%s", nsc_filter)
            self.update_clients(nsc_filter)
        instance_key = nsc_filter.instance_key
        clients = self.clients_manager.get(instance_key, set([]))
        if not clients:
            raise ConfigError(
                "exec get_client failed, nsc_filter=%s", nsc_filter)
        instance = self._get_random_client(nsc_filter, list(clients))
        if instance is None:
            raise ConfigError(
                "exec _get_random_client failed, nsc_filter=%s", nsc_filter)
        if instance_key not in self.filters_record:
            self.filters_record[instance_key] = nsc_filter
        return instance

    def _get_random_client(self, nsc_filter, clients):
        """随机获取对象实例
        :param nsc_filter: 过滤规则
        :clients: 实例
        """
        uri = nsc_filter.uri
        total_weight = 0
        filterd_total_weight = 0
        filtered_clients = []

        # 从所有的clients中过滤出符合条件的
        for cli in clients:
            if uri == cli.uri:
                filterd_total_weight += int(cli.weight)
                filtered_clients.append(cli)
            total_weight += int(cli.weight)
        # 如果存在符合条件的则从符合条件的列表筛选
        if filterd_total_weight:
            rand_num = random.randint(0, filterd_total_weight - 1)
            for cli in filtered_clients:
                rand_num -= int(cli.weight)
                if rand_num < 0:
                    return cli.instance
        # 如果没有符合条件的则从全量的clients中随机筛选
        else:
            logger.warning(
                "exec _get_random_client, nsc_filter=%s, filtered_clients=0, uri=%s", nsc_filter, uri)
            rand_num = random.randint(0, total_weight - 1)
            for cli in clients:
                rand_num -= int(cli.weight)
                if rand_num < 0:
                    return cli.instance

    def was_changed(self, nsc_filter):
        """检查配置是否发生变更
        :rtype: bool
        """
        instance_key = nsc_filter.instance_key
        namespace = nsc_filter.namespace

        current_config = self.namespaces_config.get(instance_key, {})
        new_config = self.get_config(namespace)
        if len(current_config) != len(new_config):
            return True
        for k, v in new_config.items():  # pylint: disable=invalid-name
            if current_config.get(k, None) != v:
                return True
        return False

    def update_clients(self, nsc_filter):
        """检查名字空间对应的配置项是否发生变化
        :param nsc_filter: 过滤器
        """
        instance_key = nsc_filter.instance_key
        namespace = nsc_filter.namespace

        current_config = self.namespaces_config.get(instance_key, {})
        new_config = self.get_config(namespace)
        new, removed, modified, same = get_diff_conf(
            current_config, new_config)
        logger.warning(("exec update_clients, instance_key=%s, new=%s,"
                        "removed=%s, modified=%s, same=%s"),
                       instance_key, new, removed, modified, same)
        # 新增
        if new:
            self.do_add_client(new, nsc_filter)
        # 删除
        if removed:
            self.do_remove_client(removed, nsc_filter)
        # 变更
        if modified:
            self.do_update_client(modified, nsc_filter)

        logger.warning("exec update_clients finish, current_namespace_config_len=%s, current_instances=%s", len(
            self.namespaces_config), len(self.clients_manager))

    def do_add_client(self, new_keys, nsc_filter):
        """
        :param new: 新增的服务发现节点项
        :param nsc_filter: 用于筛选新增的服务发现项过滤规则配置
        """
        namespace = nsc_filter.namespace
        new_namespace_config = self.get_config(namespace)
        instance_key = nsc_filter.instance_key
        current_namespace_config = self.namespaces_config.get(instance_key, {})

        for key in new_keys:
            config = new_namespace_config[key]
            weight = config["weight"]
            if int(weight) <= 0:
                continue
            host = config["host"]
            port = config["port"]
            uri = config["uri"]
            try:
                client = self.construct_client(
                    nsc_filter, host, port, weight, uri)
            except Exception as error:  # pylint: disable=broad-except
                Event(error).report()
                logger.error(error, exc_info=True)
                continue
            # 更新成功的对象同步更新diff的conf,更新失败的下次轮训会进行重试
            # 如果异常会打印日志，但是不影响业务使用
            current_namespace_config[key] = config

            # 一般来说client为None的情况发生在名字空间中对应的uri的配置没有找到导致
            if not client:
                continue
            if self.clients_manager.get(instance_key):
                self.clients_manager[instance_key].add(client)
            else:
                self.clients_manager[instance_key] = set([client])
            logger.warning("exec do_add_client success, client=%s", client.key)

        self.namespaces_config[instance_key] = current_namespace_config

    def do_remove_client(self, removed_keys, nsc_filter):
        """移除不用的配置
        """
        instance_key = nsc_filter.instance_key
        current_namespace_config = self.namespaces_config.get(instance_key, {})
        clients = self.clients_manager.get(instance_key, set([]))
        logger.warning("exec do_remove_client, before remove clients, clients len=%s, clients=%s", len(
            clients), clients)
        for key in removed_keys:
            config = current_namespace_config.pop(key, {})
            host = config.get("host")
            port = config.get("port")
            uri = config.get("uri")

            for cli in clients:
                if cli.host == host and cli.port == port and cli.uri == uri:
                    if cli.need_close:
                        logger.warning("exec close_client client=%s", cli.key)
                        self.close_client(cli)
                    logger.warning(
                        "exec do_remove_client success, client=%s", cli.key)
                    clients.remove(cli)
                    break

        self.namespaces_config[instance_key] = current_namespace_config
        self.clients_manager[instance_key] = clients
        logger.warning("exec do_remove_client, after remove clients, clients len=%s, clients=%s", len(
            clients), clients)

    def do_update_client(self, modified_keys, nsc_filter):
        """更新client
        """
        namespace = nsc_filter.namespace
        instance_key = nsc_filter.instance_key
        new_namespace_config = self.get_config(namespace)
        current_namespace_config = self.namespaces_config.get(instance_key, {})

        new_clients = set([])
        clients = self.clients_manager.get(instance_key, set([]))
        logger.warning("exec do_update_client, before update clients, clients len=%s, clients=%s", len(
            clients), clients)
        for cli in clients:
            for key in modified_keys:
                config = new_namespace_config[key]
                host = config["host"]
                port = config["port"]
                if cli.host == host and cli.port == port:
                    cli.uri = config["uri"]
                    cli.weight = config["weight"]
                    current_namespace_config[key] = config
                    logger.warning(
                        "exec do_update_client success, client=%s", cli.key)
                    break
            new_clients.add(cli)

        self.namespaces_config[instance_key] = current_namespace_config
        self.clients_manager[instance_key] = new_clients
        logger.warning("exec do_update_client, after update clients, clients len=%s, clients=%s", len(
            new_clients), new_clients)

    def get_config(self, namespace):
        """获取名字空间的配置，会有一个cache周期避免每次调用qconf的开销
        :param namespace: 名字空间
        """
        try:
            config = self.ttl_cache.get(namespace)
        except (KeyError, ValueError) as error:
            Event(error).report()
            logger.warning("get from ttl_cache failed, error=%s", error)
            config = None

        if config:
            return config
        try:
            services = self.zynsc_cli.get_services(namespace)
        except qconf.Error as err:  # pylint: disable=no-member
            Event(err).report()
            raise ConfigError(err)

        logger.debug("exec get_config success, services=%s", services)
        config = self.service_to_config(services)

        if not config:
            raise ConfigError(
                "exec get_config failed, namespace {}".format(namespace))

        logger.debug("exec get_config namespace=%s, config=%s",
                     namespace, config)
        try:
            self.ttl_cache[namespace] = config
        except (KeyError, ValueError) as error:
            Event(error).report()
            logger.warning("set ttl_cache failed, error=%s", error)
        return config

    @staticmethod
    def service_to_config(services):
        """将服务发现对象转为原生的配置字典
        :param services: 服务对象列表
        :return: 服务对象字典,key为service的唯一性描述
        :rtype: dict
        """
        def service_to_dict(service):
            """转换为options
            """
            try:
                weight = int(service.weight)
            except ValueError as error:
                Event(error).report()
                weight = 1
            return {
                "host": service.host,
                "port": service.port,
                "weight": weight,
                "uri": service.uri,
            }

        return {
            service.to_str(): service_to_dict(service)
            for service in services
        }

    def construct_client(self, nsc_filter, host, port, weight=1, uri="/"):
        """ 构造对象逻辑，返回对象列表
        :param nsc_filter: 过滤器
        :param host: host
        :param port: port
        :param weight: 权重默认为1
        :param uri: 配置的uri
        """
        pass

    def close_client(self, client):
        """有的对象需要主动关闭连接
        :param client: client对象，调用client对象执行close方法
        """
        pass

    def construct_client_pool(self, nsc_filter, config):
        """ 构造对象池
        """
        pass
