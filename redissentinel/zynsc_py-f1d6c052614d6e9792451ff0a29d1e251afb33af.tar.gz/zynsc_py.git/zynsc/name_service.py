# -*- coding: utf-8 -*-
"""
name_service
~~~~~~~~~~~~

名字服务相关逻辑封装

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""
from __future__ import print_function
import random
import logging as log

import requests
from zyqconf import qconf_py

from zynsc import errors
from zynsc.utils import PY2, safe_json_loads, ensure_string
from zynsc.sentryhandler.handler import Event

SPLIT_FLAG = "_"
PROVIDER_TO_NS = {}


class Service(object):
    """服务对象
    """

    def __init__(self, host, port, config=None):
        """
        :param provider: 服务提供者
        :param config: 服务提供者配置
        """
        self.host = host
        self.port = port
        if config is None or not isinstance(config, dict):
            config = {}
        # 如果配置不是int类型，不影响使用
        try:
            self.weight = int(config.get("weight", 1))
            self.disable = int(config.get("disable", 0))
        except ValueError as err:
            Event(err).report()
            self.weight = 1
            self.disable = 0
        self.idc = config.get("idc", "")  # 如果为空标示机房信息未知
        self.uri = config.get("uri", "/")

    def __repr__(self):
        return self.to_str()

    def to_dict(self):
        """转为dict类型
        """
        return {
            "host": self.host,
            "port": self.port,
            "weight": self.weight,
            "uri": self.uri,
            "idc": self.idc,
            "disable": self.disable,
        }

    def to_str(self):
        """转为字符串类型
        用冒号连接方便使用
        """
        return "{}:{}".format(self.host, self.port)

    def to_list(self):
        """转为列表类型
        """
        return [{"host": self.host, "port": self.port} for _ in range(self.weight)]

    def to_url(self, protocol="http"):
        """转换为地址
        :param protocol: 协议类型
        """
        if self.uri.startswith("/"):
            return "{protocol}://{host}:{port}{uri}".format(
                protocol=protocol, host=self.host, port=self.port, uri=self.uri
            )
        return "{protocol}://{host}:{port}/{uri}".format(
            protocol=protocol, host=self.host, port=self.port, uri=self.uri
        )


class ZKService(object):
    """qconf实现zk接入读逻辑
    使用zkapi http接口实现写逻辑
    """

    zkapi_add_consumer = "/v1/zkapi/consumers/{namespace}/{consumer}"
    zkapi_path = "/arch_group/zkapi/arch.zkapi.http/providers"
    client = qconf_py

    def __init__(self, zkapi_path=None, zkapi_add_consumer=None, cluster=""):
        """
        :param zkapi_path: zkapi服务在zk里的路径
        :param zkapi_add_consumer: zkapi服务消费者相关api
        """
        if zkapi_add_consumer:
            self.zkapi_add_consumer = zkapi_add_consumer
        if zkapi_path:
            self.zkapi_path = zkapi_path
        self.cluster = cluster or ""

    def _get_zkapi(self):
        """获取zkapi路径
        """
        zkapis = self.get_children(self.zkapi_path)
        if not zkapis:
            raise errors.ConfigError(
                "zkapi service are not available, zkpath={}".format(self.zkapi_path)
            )
        zkapi = random.choice(zkapis)
        if not PY2:
            zkapi = zkapi.decode("utf8")
        host, port = zkapi.split(SPLIT_FLAG)
        return "http://{}:{}".format(host, port)

    def get_zkapi_consumer_url(self, namespace, consumer):
        """获取请求zkapi的url
        """
        zkapi_uri = self.zkapi_add_consumer.format(
            namespace=namespace, consumer=consumer
        )
        zkapi_host = self._get_zkapi()
        return zkapi_host + zkapi_uri

    def get(self, path):
        """获取节点路径的值
        :param path: 节点路径
        """
        try:
            return self.client.get_conf(path, self.cluster)
        except qconf_py.Error as err:
            Event(err).report()
            log.error("exec get failed, path=%s, err=%s", path, err)
            return None

    def get_children(self, path):
        """获取指定路径的子节点
        :param path: 节点路径
        """
        try:
            return self.client.get_batch_keys(path, self.cluster)
        except qconf_py.Error as err:
            Event(err).report()
            log.error("exec get_children failed, path=%s, err=%s", path, err)
            return []

    def get_nodes(self, path):
        """获取指定路径的子节点及其配置
        :param path: 节点路径
        """
        try:
            return self.client.get_batch_conf(path, self.cluster)
        except qconf_py.Error as err:
            Event(err).report()
            log.error("exec get_nodes failed, path=%s, err=%s", path, err)
            return {}

    def create(self, namespace, consumer, timeout=1):
        """创建zk节点
        """
        url = self.get_zkapi_consumer_url(namespace, consumer)
        try:
            res = requests.post(url, timeout=timeout)
        except requests.exceptions.RequestException as error:
            Event(error).report()
            log.error(
                "exec create failed, namespace=%s, consumer=%s, error=%s",
                namespace,
                consumer,
                error,
            )
            return False
        if res.status_code != 201:
            log.error(
                "exec create failed, status_code=%s, namespace=%s, consumer=%s",
                res.status_code,
                namespace,
                consumer,
            )
            return False
        return True

    def delete(self, namespace, consumer, timeout=1):
        """删除zk节点
        """
        url = self.get_zkapi_consumer_url(namespace, consumer)
        try:
            res = requests.delete(url, timeout=timeout)
        except requests.exceptions.RequestException as error:
            Event(error).report()
            log.error(
                "exec delete failed, namespace=%s, consumer=%s, error=%s",
                namespace,
                consumer,
                error,
            )
            return False
        if res.status_code != 204:
            log.error(
                "exec delete failed, status_code=%s, namespace=%s, consumer=%s",
                res.status_code,
                namespace,
                consumer,
            )
            return False
        return True


class NameService(object):
    """名字服务相关的类
    """

    namespace_tpl = "/{zk_prefix}/{namespace}"
    providers_tpl = "/{zk_prefix}/{namespace}/providers"
    consumers_tpl = "/{zk_prefix}/{namespace}/consumers"
    service_path_tpl = "{path}/{provider}"
    consumer_tpl = "{host}_{port}"

    def __init__(self, config, cluster=None):
        """
        """
        self.zk_prefix = config.get("zk_prefix", "arch_group/zkapi")
        self.cluster = cluster
        self.zk_service = ZKService(
            config.get("zkapi_path"),
            config.get("zkapi_add_consumer"),
            cluster=self.cluster,
        )

    def get_namespace_path(self, namespace):
        """获取名字空间路径
        :param namespace: 名字空间
        """
        return self.namespace_tpl.format(zk_prefix=self.zk_prefix, namespace=namespace)

    def get_namespaces(self):
        """ 获取全部名字空间列表
        """
        result = self.zk_service.get_children(self.zk_prefix)
        if not result:
            return []
        return [ensure_string(namespace) for namespace in result]

    def get_providers_path(self, namespace):
        """根据名字空间获取生产者zk的路径
        :param namespace: 名字空间
        """
        return self.providers_tpl.format(zk_prefix=self.zk_prefix, namespace=namespace)

    def get_service_path(self, path, provider):
        """生成服务路径
        :param path: providers_path
        :param provider: 服务提供者{host}_{port}
        """
        return self.service_path_tpl.format(path=path, provider=provider)

    def get_consumers(self, namespace):
        """获取服务消费者列表
        :param namespace: 名字空间
        :rtype: list
        """
        if not namespace:
            return []
        consumers_path = self.get_consumers_path(namespace)
        result = self.zk_service.get_children(consumers_path)
        if not result:
            return []
        return result

    def get_namespace_config(self, namespace):
        """获取名字空间配置
        :param namespace: 名字空间
        :rtype: dict
        """
        if not namespace:
            return {}
        namespace_path = self.get_namespace_path(namespace)
        result = self.zk_service.get(namespace_path)
        if not result:
            return {}
        return safe_json_loads(result)

    def get_providers(self, namespace):
        """获取服务提供者列表
        :param namespace: 名字空间
        :rtype: list
        """
        if not namespace:
            return []
        providers_path = self.get_providers_path(namespace)
        result = self.zk_service.get_children(providers_path)
        if not result:
            raise errors.NotFoundError(
                "{} is not exists in zookeeper".format(providers_path)
            )
        return result

    def get_provider(self, namespace, provider):
        """获取服务提供者信息
        :param namespace: 名字空间
        :param provider: 服务提供者
        """
        providers_path = self.get_providers_path(namespace)
        service_path = self.get_service_path(providers_path, provider)
        result = self.zk_service.get(service_path)
        if not result:
            log.error("no are avalible in %s", namespace)
            raise errors.NotFoundError(
                "{} is not exists in zookeeper".format(service_path)
            )
        return result

    def get_providers_with_config(self, namespace):
        """批量获取provider和服务配置信息
        :param namespace: 名字空间
        :rtype: dict
        """
        if not namespace:
            return {}
        providers_path = self.get_providers_path(namespace)
        nodes = self.zk_service.get_nodes(providers_path)
        if not nodes:
            raise errors.NotFoundError(
                "{} is not exists in zookeeper".format(providers_path)
            )
        return nodes

    def get_services(self, namespace):
        """获取服务列表,以及服务配置信息
        :param namespace: 名字空间
        """
        services = []
        providers = self.get_providers_with_config(namespace)
        for provider, config in providers.items():
            config = safe_json_loads(config)
            host, port = provider.split(SPLIT_FLAG)
            service = Service(host, port, config)
            # disable > 0 表示服务被禁用
            if service.disable > 0:
                continue
            if service.weight > 0:
                PROVIDER_TO_NS[provider] = namespace
                services.append(service)
        return services

    def get_consumers_path(self, namespace):
        """根据名字空间获取消费者zk的路径
        :param namespace: 名字空间
        """
        return self.consumers_tpl.format(zk_prefix=self.zk_prefix, namespace=namespace)
