# -*- coding: utf-8 -*-
"""
algorithm
~~~~~~~~~~~~

路由选择算法实现

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""
import random as random_sys
from binascii import crc32
from enum import Enum
from zynsc import utils

try:
    xrange  # py2
except NameError:
    xrange = range  # py3


class AlgorithmType(Enum):
    """算法类型
    """
    random = 1  # 随机
    weight_random = 2  # 加权随机
    source_hashing = 3  # 源地址散列
    local_first = 4  # 优先使用本机
    uri_service = 5  # 返回所有符合条件的服务


def random(services, **kwargs):
    """随机选择服务服务
    :param services: 服务列表配置信息
    :param uri (optional): 最长匹配逻辑需要用到
    :type uri: str
    :return: 返回服务对象
    :rtype: zynsc.name_service.Service
    """
    # todo: 字符串最长匹配原则选择,需要设计O(nlog(n))算法避免耗时
    # 参考：https://en.wikipedia.org/wiki/Longest_common_substring_problem
    # https://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Longest_common_substring#Python_2
    filter_services = _filter_services_by_uri(services, kwargs.get("uri"))
    return random_sys.choice(filter_services)


def uri_service(services, **kwargs):
    """返回符合uri规则的服务列表
    :param services: 服务列表配置信息
    :return: 返回服务对象列表
    :rtype: [zynsc.name_service.Service]
    """
    return _filter_services_by_uri(services,
                                   kwargs.get("uri", "/"))


def weight_random(services, **kwargs):
    """加权随机
    """
    weighted_services = _get_weighted_services(services)
    filter_services = _filter_services_by_uri(weighted_services,
                                              kwargs.get("uri"))
    return random_sys.choice(filter_services)


def source_hashing(services, **kwargs):
    """源站哈希
    """
    source = utils.get_host()
    if isinstance(source, str):
        source = source.encode("utf8")
    filter_services = _filter_services_by_uri(services, kwargs.get("uri"))
    hash_num = crc32(source) % len(filter_services)
    return services[hash_num]


def local_first(services, **kwargs):
    """优先使用本机的IP，当本机不存在时加权随机选择
    todo(wlc): 优化多次遍历services的算法不够高效,有重复计算的逻辑
    """
    # 加权
    weighted_services = _get_weighted_services(services)
    # 过滤uri规则
    filter_services = _filter_services_by_uri(weighted_services,
                                              kwargs.get("uri"))
    # 过滤服务器IP
    local_services = _get_local_service(filter_services)
    return random_sys.choice(local_services)


def _get_local_service(services):
    """获取本机服务
    1, 当本机为多个端口，切且权重不同的场景需要考虑;
    2, 当本机没有服务，选择其他服务器时也需要加权随机
    """
    local_ip = utils.get_host()
    if not isinstance(local_ip, str):
        local_ip = local_ip.encode("utf8")
    if not local_ip:
        return services
    local_services = [
        service for service in services if service.host == local_ip
    ]
    if local_services:
        return local_services
    return services


def _get_weighted_services(services):
    """获取加权后的服务列表
    """
    weighted_services = []
    for service in services:
        # weight <= 0 的服务按照下线对待
        if service.weight > 0:
            weighted_services.extend([service] * service.weight)
    return weighted_services


def _filter_services_by_uri(services, uri):
    """基于uri过滤services
    :param services: 服务列表对象
    :param uri: 输入参数
    """
    # 没有配置uri的时候走全部服务列表
    if not uri:
        return services
    uri = uri.strip()
    if uri != "/":
        filter_services = [
            service for service in services if service.uri == uri
        ]
        if filter_services:
            return filter_services
    return services


def long_substr(data):
    """从列表中取出最长字符串
    :param data: 多个字符串
    :type data: list
    """

    # substrs = lambda x: {
    #     x[i:i + j]
    #     for i in xrange(len(x))
    #     for j in xrange(len(x) - i + 1)
    # }
    def substrs(x):  # pylint: disable=invalid-name
        """找子字符串
        """
        return {
            x[i:i + j]
            for i in xrange(len(x)) for j in xrange(len(x) - i + 1)
        }

    substr = substrs(data[0])
    for val in data[1:]:
        substr.intersection_update(substrs(val))
    return max(substr, key=len)
