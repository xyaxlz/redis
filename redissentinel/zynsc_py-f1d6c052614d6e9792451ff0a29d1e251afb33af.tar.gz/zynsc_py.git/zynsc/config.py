# -*- coding: utf-8 -*-

"""
config
~~~~~~~~~~~~

nameservice配置模块

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-24

"""

CONFIG = {
    "port_env_name": "ZYAGENT_HTTPPORT",
    "zk_prefix": "arch_group/zkapi",
    "zkapi_path": "/arch_group/zkapi/arch.zkapi.http/providers",
    "zkapi_add_consumer": "/v1/zkapi/consumers/{namespace}/{consumer}",
    # 如果qconf集群名称不一致需要独立进行配置,统一基于别名进行查找
    "clusters": {
        "default": "",  # 使用服务器的共享内存的默认集群
        "m5": "qconf_online",
        "yz": "qconf_yz_online",
    }
}
