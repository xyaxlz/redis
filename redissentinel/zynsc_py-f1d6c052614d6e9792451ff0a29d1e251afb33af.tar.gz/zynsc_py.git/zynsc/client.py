# -*- coding: utf-8 -*-
"""
client
~~~~~~~~~~~~

接口对外接口

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""
import logging as log
import traceback
import time
import re
import json

from zyqconf import qconf_py
from zynsc.config import CONFIG
from zynsc import algorithms
from zynsc import utils
from zynsc.algorithms import AlgorithmType
from zynsc.name_service import NameService, PROVIDER_TO_NS
from zynsc.report import Reporter
from zynsc.sentryhandler.handler import Event


def get_ns(provider):
    """通过provider查找名字空间
    """
    return PROVIDER_TO_NS.get(provider, "")


def get_current_idc():
    """获取当前机房名称
    """
    return utils.ensure_string(qconf_py.get_conf("/arch_group/idc/current"))


def get_current_namespace():
    """获取当前服务名字空间
    """
    return utils.get_env("NAMESPACE")


def get_current_project():
    """获取当前项目名称
    """
    return utils.get_env("PROJECT_NAME")


def get_project_info(project):
    """ 获取项目信息
    """
    config = qconf_py.get_batch_conf("/arch_group/amqp_proxy/project")
    for val in config.values():
        try:
            conf = json.loads(val)
            name = conf.get("name")
            if name != project:
                continue
            return int(conf.get("switch", 0))
        except (ValueError, KeyError) as err:
            continue
    return 0


def is_consumer_ok():
    """ rabbitmq 生产者消费者消费条件
    :rtype: bool
    """
    project = get_current_project()
    if not project:
        log.warning("no project in env")
        return False
    project_switch = get_project_info(project)
    if project_switch > 0:
        return True
    return False


class NSClient(utils.SingletonMixin):
    """name service client
    """

    cached_success = {}
    registerted_namespaces = {
        "idc": get_current_idc(),
        "project": get_current_project(),
        "namespace": get_current_namespace(),
        "depends": {"human": {}, "auto": {}},
    }
    timeout = 3
    host = utils.get_host()
    port = None
    config = None
    name_service = None
    clusters = {}
    current_cluster = None

    def init(self, port=None, config=None, timeout=3):
        """
        :param algorithm: 使用选取服务的类型
        :param port: 当前服务端口
        :param timeout: 超时时间
        :param config: 额外配置
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
        """
        self.timeout = timeout
        self.config = config or CONFIG
        if port is not None:
            self.port = port
        else:
            try:
                self.port = int(
                    utils.get_env(self.config.get("port_env_name", "ZYAGENT_HTTPPORT"))
                )
            except ValueError as err:
                self.port = None
        self.clusters = self.config.get("clusters", {})
        if not self.clusters:
            log.warning(
                "clusters was not in config, please check config when call init!"
            )
        self.current_cluster = self.clusters.get("default")
        self.name_service = NameService(self.config, self.current_cluster)
        self.reporter = Reporter()
        self.registerted_namespaces["host"] = self.host
        self.registerted_namespaces["port"] = self.port
        return self

    def use_cluster(self, cluster=""):
        """获取集群名称,链式表达,可以在调用函数前执行use_cluster来显示表示使用的集群

        :param cluster: 集群的配置名称
        """
        if not cluster:
            return self.clusters.get("default", "")
        self.current_cluster = self.clusters.get(cluster, "")
        # 变更集群
        self.name_service = NameService(self.config, self.current_cluster)
        return self

    def register_by_human(self, namespaces):
        """显示指定依赖关系,人为指定可以指定多个名字空间
        :param namespaces: 服务依赖的名字空间列表
        :type namespaces:  list
        """
        if not namespaces:
            return
        if not isinstance(namespaces, list):
            return
        for namespace in namespaces:
            self.register(namespace, kind="human")

    def register(self, namespace, kind="auto"):
        """注册自己为某名字空间的消费者
        最好在服务启动的时候执行register,当端口不存在的时候无须注册
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        :param kind: 用于说明是人工指定还是自动发现, kind为human表示人工指定，kind为auto表示自动发现
        :type kind: str
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
            >>> nsc.register("cps.newcps.http")
        """
        current_time = time.time()
        if namespace in self.registerted_namespaces["depends"][kind]:
            self.registerted_namespaces["depends"][kind][namespace] += 1
        else:
            self.registerted_namespaces["depends"][kind][namespace] = 1
        self.registerted_namespaces["update_time"] = current_time
        # 进行上报
        self.reporter.set_topic("name_service_consumer").set_msg_type("json").report(
            self.registerted_namespaces
        )

    def get_mock_info(self, namespaces, first_exit=True):
        """获取名字空间配置判断是否是mock
        :param namespaces: 名字空间列表
        :param first_exit: 发现第一个时就立即返回，用来粗粒度判断用
        """
        mock_result = {"is_mock": 0, "details": {}}
        if not namespaces:
            return mock_result
        if not isinstance(namespaces, list):
            return mock_result
        for ns in namespaces:  # pylint: disable=invalid-name
            ns_conf = self.name_service.get_namespace_config(ns)
            if ns_conf.get("mock", False):
                mock_result["details"][ns] = []
                mock_result["is_mock"] = 1
                if first_exit:
                    return mock_result
        return mock_result

    def services(self, namespace):
        """获取服务列表,需要设置缓存时间
        设定刷新周期
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        """
        try:
            self.register(namespace)
            # 记录上次成功获取的服务列表,以防万一zk故障同时qconf故障时服务不可用
            last_success = self.name_service.get_services(namespace)
            self.cached_success[namespace] = last_success
            return last_success
        except Exception as err:  # pylint: disable=broad-except
            Event(err).report()
            log.error("exec services, error=%s", traceback.format_exc())
            return self.cached_success.get(namespace, [])

    def get_services(self, namespace):
        """获取服务列表
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        """
        return self.services(namespace)

    def get_master_service(
        self, namespace, algorithm=AlgorithmType.weight_random, default=None
    ):
        """获取主服务器信息
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        :param algorithm (optional): 算法选择,参数非必选,默认为随机
        :type algorithm: AlgorithmType
        :param default (optional): 构造的service对象
        :type default: :class:`Service <Service>` object
        :return: :class:`Service <Service>` object
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
            >>> service = nsc.get_master_service("cps.newcps.http")
            >>> service.to_dict()
            {"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/master"}
        """
        return self.get_service(namespace, algorithm, default, uri="/master")

    def get_slave_service(
        self, namespace, algorithm=AlgorithmType.uri_service, default=None
    ):
        """获取从服务器信息
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        :param algorithm (optional): 算法选择,参数非必选,默认为随机
        :type algorithm: AlgorithmType
        :param default (optional): 构造的service对象
        :type default: :class:`Service <Service>` object
        :return: [:class:`Service <Service>`] list
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
            >>> service = nsc.get_slave_service("cps.newcps.http")
            >>> service
            [{"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/slave"}]
        """
        return self.get_service(namespace, algorithm, default, uri="/slave")

    def get_slow_service(
        self, namespace, algorithm=AlgorithmType.weight_random, default=None
    ):
        """获取慢服务器信息
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        :param algorithm (optional): 算法选择,参数非必选,默认为随机
        :type algorithm: AlgorithmType
        :param default (optional): 构造的service对象
        :type default: :class:`Service <Service>` object
        :return: :class:`Service <Service>` object
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
            >>> service = nsc.get_slow_service("cps.newcps.http")
            >>> service.to_dict()
            {"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/slow"}
        """
        return self.get_service(namespace, algorithm, default, uri="/slow")

    def get_service(
        self,
        namespace,
        algorithm=AlgorithmType.weight_random,
        default=None,
        uri="/",
        **kwargs
    ):
        """获取服务提供者逻辑
        :param namespace: 名字空间,{group}_{service}_{type}
        :type namespace: str
        :param algorithm (optional): 算法选择,参数非必选,默认为随机
        :type algorithm: AlgorithmType
        :param default (optional): 构造的service对象
        :type default: :class:`Service <Service>` object
        :param uri (optional): 期望获取的uri地址,算法模块会根据该参数进行最长匹配模式选择和uri匹配度最高的service返回
        :type uri: str
        :return: :class:`Service <Service>` object or list 当algorithm为uri_service时返回为列表结构，其他均为Service对象或者default值
        Usage::
            >>> from zynsc import NSClient
            >>> nsc = NSClient.instance().init("4455")
            >>> service = nsc.get_service("cps.newcps.http")
            >>> service.to_dict()
            {"host": "192.168.3.2", "port": 4455, "weight": 1, "uri": "/"}
        """
        try:
            services = self.services(namespace)
            # 如果获取列表失败直接返回默认值
            if not services:
                return default
            algorithm_func = getattr(algorithms, algorithm.name)
            return algorithm_func(services, uri=uri, **kwargs)
        except Exception as err:  # pylint: disable=broad-except
            Event(err).report()
            log.error("exec get_service, error=%s", traceback.format_exc())
            return default

    def get_namespace_idc(self, namespace):
        """获取当前名字空间提供服务的机房,如果没有配置默认为当前机房

        :param namespace: 名字空间
        :type namespace: str
        """
        return self.name_service.get_namespace_config(namespace).get(
            "zone", get_current_idc()
        )

    def get_namespaces(self, regex=None):
        """ 获取所有符合条件的名字空间
        :param regex: 正则条件过滤,需要re.compile之后，性能最佳
        :return: 返回符合条件的名字空间列表
        :rtype: list
        """
        namespaces = self.name_service.get_namespaces()
        if not regex:
            return namespaces
        result = []
        for namespace in namespaces:
            if re.search(regex, namespace):
                result.append(namespace)
        return result

    def get_namespace_config(self, namespace):
        """ 获取指定名字空间的配置信息
        :param namespace: 名字空间
        """
        return self.name_service.get_namespace_config(namespace)
