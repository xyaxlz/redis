#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
test_api
~~~~~~~~~~~~

测试api相关接口

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-24

"""

# pylint: disable=all
import mock
import pytest
import requests

import zynsc
from zynsc import name_service
from zynsc.client import NSClient
from zynsc import utils
from zynsc.algorithms import AlgorithmType

from zyqconf import qconf_py
# mock qconf get_batch_conf
qconf_py_get_batch_conf_return = {
    '192.168.6.7_4455': '{"uri": "/", "weight": 1}',
    '10.0.2.15_2233': '{"uri": "/", "weight": 1}',
    '192.168.2.15_1235': '{"uri": "/master", "weight": 1}',
    '192.168.3.15_2233': '{"uri": "/master", "weight": 0}',
    '192.168.4.15_5233': '{"uri": "/slave", "weight": 1}',
    '192.168.4.15_2233': '{"uri": "/slave", "weight": 0}',
    '192.168.13.15_2233': '',
    '192.16.4.15_2233': '{"uri": "/slow", "weight": 1}',
    '122.16.3.15_2233': '{"uri": "/slow", "weight": 0}',
    '192.168.36.7_4455': '{"uri": "/newcps/test", "weight": 1}',
    '192.168.26.7_4455': '{"uri": "/newcps/test", "weight": 1, "disable": 1}',
    '192.168.7.32_4455': '',
}

qconf_py_get_conf_return = "m5"


def test_client_get_service():
    """测试获取服务
    """

    qconf_py_mock1 = mock.Mock(return_value=qconf_py_get_batch_conf_return)

    # 测试名字空间存在
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock1):
        cli = NSClient.instance().init()
        service = cli.get_service("cps.content.http")
        assert isinstance(service, name_service.Service)
        service_dict = service.to_dict()
        print(service_dict)
        assert "host" in service_dict
        assert "port" in service_dict

    # 测试名字空间不存在的场景
    qconf_py_mock2 = mock.Mock(return_value={})
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock2):
        default = name_service.Service("192.168.6.7", 3322)
        service = cli.get_service("cps.content.http1", default=default)
        assert service.to_str() == "192.168.6.7:3322"

    # 测试算法选择逻辑
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock1):
        service = cli.get_service("cps.content.http", uri="/newcps/test")
        assert service.to_str()
        service = cli.get_service(
            "cps.content.http",
            algorithm=AlgorithmType.random,
            uri="/newcps/test")
        assert service.to_str()
        assert service.host == "192.168.36.7"

        service = cli.get_service(
            "cps.content.http",
            algorithm=AlgorithmType.source_hashing,
            uri="/newcps/test")
        assert service.to_str()
        assert service.to_url().startswith("http://")
        service = cli.get_service(
            "cps.content.http",
            algorithm=AlgorithmType.local_first,
            uri="/newcps/test")
        assert service.to_str()

        # mock本机IP
        localhost_mock = mock.Mock(return_value="10.0.2.15")
        with mock.patch.object(utils, "get_host", localhost_mock):
            service = cli.get_service(
                "cps.content.http", algorithm=AlgorithmType.local_first)
            assert service.to_str()
            assert service.host == "10.0.2.15"

        localhost_mock1 = mock.Mock(return_value="10.0.2.16")
        with mock.patch.object(utils, "get_host", localhost_mock1):
            service = cli.get_service(
                "cps.content.http", algorithm=AlgorithmType.local_first)
            print(service.to_str())
            assert service.host != "10.0.2.16"


def test_get_service_exception():
    """测试服务异常的场景
    """
    cli = NSClient.instance().init()

    get_batch_conf_return = {
        '192.168.6.7_4455': '{"uri": "/", "weight": 1}',
    }
    qconf_py_mock1 = mock.Mock(return_value=get_batch_conf_return)
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock1):
        service = cli.get_master_service("arch.content.http")
        assert service.host == "192.168.6.7"
        assert service.port == "4455"
        assert "cps.content.http" in cli.cached_success

    qconf_py_mock2 = mock.Mock(return_value={})
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock2):
        assert "cps.content.http" in cli.cached_success
        service = cli.get_master_service("arch.content.http")
        assert service.host == "192.168.6.7"
        assert service.port == "4455"
    get_batch_conf_return1 = {
        '192.168.45.7_4466': '{"uri": "/", "weight": 1}',
    }
    qconf_py_mock3 = mock.Mock(return_value=get_batch_conf_return1)
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock3):
        service = cli.get_master_service("arch.content.http")
        assert service.host == "192.168.45.7"
        assert service.port == "4466"


def test_get_special_service():
    """测试获取特殊服务
    """
    qconf_py_mock1 = mock.Mock(return_value=qconf_py_get_batch_conf_return)
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock1):
        cli = NSClient.instance().init()
        service = cli.get_master_service("cps.content.http")
        assert service.host == "192.168.2.15"
        assert service.port == "1235"
        service_list = cli.get_slave_service("cps.content.http")
        print(service_list)
        assert len(service_list) == 1
        service = cli.get_slow_service("cps.content.http")
        assert service.host == "192.16.4.15"
        assert service.port == "2233"


def test_disable_service():
    """测试禁用服务的配置生效情况
    """
    qconf_py_mock1 = mock.Mock(return_value=qconf_py_get_batch_conf_return)
    with mock.patch.object(qconf_py, "get_batch_conf", qconf_py_mock1):
        cli = NSClient.instance().init()
        services = cli.get_services("cps.content.http")
        assert len(services) == 8
        for s in services:
            assert s.host != "192.168.26.7"

        service = cli.get_master_service("cps.content.http")
        assert service.host == "192.168.2.15"
        assert service.port == "1235"
        service_list = cli.get_slave_service("cps.content.http")
        assert len(service_list) == 1
        service = cli.get_slow_service("cps.content.http")
        assert service.host == "192.16.4.15"
        assert service.port == "2233"


def test_client_register():
    """测试注册和取消注册逻辑
    """

    # mock requests

    class HttpResponse(object):

        def __init__(self, status_code):
            self.status_code = status_code

    requests_post_return = mock.Mock(return_value=HttpResponse(201))
    requests.post = requests_post_return
    requests_delete_return = mock.Mock(return_value=HttpResponse(204))
    requests.delete = requests_delete_return

    cli = NSClient.instance().init("4433")
    cli.register("cps.content.http")

def test_client_get_current_idc():
    qconf_py_mock1 = mock.Mock(return_value=qconf_py_get_conf_return)
    with mock.patch.object(qconf_py, "get_conf", qconf_py_mock1):
        idc = zynsc.get_current_idc()
        assert idc == "m5"

def test_get_namespaces():
    """ 获取名字空间
    """
    # todo
    pass

def test_is_consumer_ok():
    zynsc.is_consumer_ok()
