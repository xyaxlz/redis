# -*- coding: utf-8 -*-

"""
test_utils
~~~~~~~~~~~~

测试utils

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-25

"""
# pylint: disable=all
from zynsc import utils
from zynsc.utils import (
    SingletonMixin,
    if_exception_return,
    EXCEPT_RETURN,
)


def test_get_host():
    """测试获取主机IP
    """
    ip = utils.get_host()
    print(type(ip))
    print(ip)
    assert ip.count(".") == 3


class A(SingletonMixin):
    """ 测试类A
    """
    a = []

    def add(self, data):
        self.a.append(data)


class B(SingletonMixin):
    """ 测试类B
    """
    pass


def test_singleton():
    a1, a2 = A.instance(), A.instance()
    a1.add(1)
    a2.add(2)
    assert a1 is a2
    assert a1.a is a2.a


def test_if_exception_return():
    """测试异常返回装饰器
    """
    @if_exception_return(Exception, cache_key_pos=0)
    def test(namespace, default=None):
        raise ValueError("value error")
        return namespace

    assert test("test", default=23) == 23
    assert "test" in EXCEPT_RETURN

    @if_exception_return(Exception, cache_key_pos=0)
    def test1(namespace, default=None, cache_key=None):
        raise ValueError("value error")
        return namespace

    assert test1(test, default=234, cache_key="haha") == 234
    assert "haha" in EXCEPT_RETURN

def test_safe_json_loads():
    test_data = [
        "",
        '{"reserve_num": 5, "mock": false, "never_delete": true, "safe_rate": 0.2}',
        '{"reserve_num": 5, ,"mock": false, "never_delete": true, "safe_rate": 0.2}',
        '{"reserve_num": 5,| ,"mock": false, "never_delete": true, "safe_rate": 0.2}',
        '{"reserve_num": 5, "mock": true, "never_delete": true, "safe_rate": 0.2}',
    ]
    r0 = utils.safe_json_loads(test_data[0])
    r1 = utils.safe_json_loads(test_data[1])
    r2 = utils.safe_json_loads(test_data[2])
    r3 = utils.safe_json_loads(test_data[3])
    r4 = utils.safe_json_loads(test_data[4])
    assert isinstance(r0, dict)
    assert len(r0) == 0
    assert isinstance(r1, dict)
    assert len(r1) == 4
    assert isinstance(r1["mock"], bool)
    assert r1["mock"] is False
    assert isinstance(r2, dict)
    assert len(r2) == 0
    assert isinstance(r3, dict)
    assert len(r3) == 0
    assert isinstance(r4, dict)
    assert len(r4) == 4
    assert isinstance(r4["mock"], bool)
    assert r4["mock"] is True
