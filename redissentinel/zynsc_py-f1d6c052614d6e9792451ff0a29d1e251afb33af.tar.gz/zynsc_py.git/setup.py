#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
setup
~~~~~~~~~~~~

安装配置

:copyright: (c) 2016 zhangyue
:authors: wanglichao
:version: 1.0 of 2016-08-18

"""
import sys
import re
from setuptools import find_packages

try:
    from distutils.core import setup
except ImportError:
    from setuptools import setup

PY2 = sys.version_info[0] == 2
INSTALL_REQUIRES = ["requests>=2.9.0", "PyYAML>=3.10"]

VERSION = ''
if PY2:
    with open('zynsc/__init__.py', 'r') as fd:
        VERSION = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]',
                            fd.read(), re.MULTILINE).group(1)
    INSTALL_REQUIRES.append("enum34>=1.1.0")
else:
    with open('zynsc/__init__.py', 'r', encoding='utf-8') as fd:
        VERSION = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]',
                            fd.read(), re.MULTILINE).group(1)


if not VERSION:
    raise RuntimeError('Cannot find version information')


setup(
    name='zynsc',
    version=VERSION,
    py_modules=['zynsc'],
    packages=find_packages(),
    long_description="zhang yue name service client",
    package_dir={"zynsc": "zynsc"},
    author="wanglichao",
    author_email="wanglichao@zhangyue.com",
    description="zhangyue name service python client Package",
    license="Apache 2.0",
    keywords="name service client",
    url="http://192.168.6.70/architecture/zynsc_py/tree/master",
    install_requires=INSTALL_REQUIRES,
)
